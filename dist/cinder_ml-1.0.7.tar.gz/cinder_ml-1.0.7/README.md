# Cinder

A powerful machine learning model debugging and analysis dashboard.

## Installation

```bash
pip install cinder-ml